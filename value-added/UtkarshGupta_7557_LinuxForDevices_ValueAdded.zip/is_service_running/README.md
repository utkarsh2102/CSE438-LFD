## Backup Script

## Instructions for running:

Run this script along with the service as a command-line
argument that you want to check if it's running or not.
`./is_service_running.sh $name_of_the_service`

For example:
`$ ./is_service_running.sh bluetooth`

## Author

Utkarsh Gupta <<utkarsh@debian.org>> (A2305217557)
