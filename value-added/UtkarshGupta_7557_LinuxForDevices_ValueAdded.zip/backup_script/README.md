## Backup Script

## Instructions for running:

To run this shell script, just use this executable in the
following way:
`$ ./backup.sh $path_to_directory`

For example:
`$ ./backup.sh /home/utkarsh/imp_data/`

## Author

Utkarsh Gupta <<utkarsh@debian.org>> (A2305217557)
