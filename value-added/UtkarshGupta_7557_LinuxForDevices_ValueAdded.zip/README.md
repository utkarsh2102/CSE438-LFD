## Value Added Lab Experiments

This contains a some value added lab experiments that are
done duing the class of CSE438 - Linux For Devices.

It contains the following scripts & programs:

1. `backup_script`: a shell script to backup your system and upload to the server.
2. `counting_files`: a shell script to count the files in a given directory.
3. `is_service_running`: a shell script to check wheter some service is running or not.
4. `monitor_system`: a shell script to monitor your entire system.
5. `socket_programming`: a C program to perform a file tranfer using TCP connection.


## Author

Utkarsh Gupta <<utkarsh@debian.org>> (A2305217557)
