## Backup Script

## Instructions for running:

Run this script with a path to directory as a
command-line argument.
`./count_files.sh $path_to_some_directory`

For example:
`$ ./count_files.sh /etc/grub.d`

## Author

Utkarsh Gupta <<utkarsh@debian.org>> (A2305217557)
