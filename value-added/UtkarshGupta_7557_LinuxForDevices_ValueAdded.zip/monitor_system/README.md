## System Monitoring

## Instructions for running:

Just the run the script as is without any args.
`./system_monitoring.sh`

For example:
`$ ./system_monitoring.sh`

## Author

Utkarsh Gupta <<utkarsh@debian.org>> (A2305217557)
